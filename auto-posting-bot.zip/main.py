import tweepy
import schedule
import time
from config import CONSUMER_KEY, CONSUMER_SECRET, ACCESS_TOKEN, ACCESS_TOKEN_SECRET

def authenticate_twitter_app():
    try:
        client = tweepy.Client(
            consumer_key=CONSUMER_KEY,
            consumer_secret=CONSUMER_SECRET,
            access_token=ACCESS_TOKEN,
            access_token_secret=ACCESS_TOKEN_SECRET
        )
        print("Authentication successful")
        return client
    except Exception as e:
        print(f"Authentication error: {e}")

def post_tweet(client, message):
    try:
        response = client.create_tweet(text=message)
        print("Successfully posted tweet!", response)
    except Exception as e:
        print(f"Error: {e}")

def job():
    print("Attempting to post tweet...")
    client = authenticate_twitter_app()
    message = "Hello, this is an automated tweet!"
    post_tweet(client, message)
    print("Tweet posted!")

schedule.every().day.at("02:01").do(job)

while True:
    print("Waiting for scheduled time...")
    schedule.run_pending()
    time.sleep(1)