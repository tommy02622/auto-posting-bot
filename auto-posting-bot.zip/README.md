# Auto Posting Bot

This is a simple Twitter auto-posting bot using Python.

## Setup

1. Clone the repository.
2. Install the required packages: